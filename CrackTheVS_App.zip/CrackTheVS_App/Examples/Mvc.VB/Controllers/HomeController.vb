﻿Namespace Controllers
    Partial Public Class HomeController
        Inherits Controller

        Function Index() As ActionResult
            Return View()
        End Function

    End Class
End Namespace
